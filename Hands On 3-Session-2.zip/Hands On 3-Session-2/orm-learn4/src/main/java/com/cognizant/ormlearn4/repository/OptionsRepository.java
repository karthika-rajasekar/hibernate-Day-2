package com.cognizant.ormlearn4.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.ormlearn4.model.Options;

public interface OptionsRepository extends JpaRepository<Options, String>{

}
