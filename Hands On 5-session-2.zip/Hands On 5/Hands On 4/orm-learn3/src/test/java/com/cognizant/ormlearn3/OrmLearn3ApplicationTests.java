package com.cognizant.ormlearn3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmLearn3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
